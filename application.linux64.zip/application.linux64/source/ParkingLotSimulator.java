import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class ParkingLotSimulator extends PApplet {


int stallWidth=60; 
int stallHeight=40;
Street sstr = new Street(0, 675);
Street cstr = new Street(460, 0);
Street nstr = new Street(0, 0);
ParkingLot pLot =  new ParkingLot(150, 200, stallWidth, stallHeight);//100,100 is location of the first lot; 
Gate exitGate = new Gate(360, 595, "Exit");
Gate enterGate = new Gate(360, 105, "Entrance");
Date presentDate= new Date(0, 8, 0, true);
Car carArray[]=new Car[1];
ControlPanel cP= new ControlPanel();
int timeCounter=0;
boolean pause= false;
public void settings() 
{
  size(1200, 800);
}

public void setup() 
{
  frameRate(30);
  carArray[0]=new Car(0, 50);
}

public void draw() 
{
  if(timeCounter%4==0)
  {
  presentDate.addMinute();
  cP.time++;
  }
  drawbackground();
timeCounter+=1;
  if (random(0, 30)<=2&& timeCounter>30) 
  {
    carArray=(Car[])append(carArray, new Car(0, 75));
    timeCounter=0;
  }
  for (int i=0; i<carArray.length; i++) 
  {
    carArray[i].driveCar();
  }
  cP.DrawControlPanel();
}

public void drawbackground() 
{
  background(0, 100, 0);
  fill(255);
  rect(95, 135, 810, 500); 
  fill(78, 78, 78);
  stroke(255);

  rect(100, 140, 800, 490);

  cstr.DrawConnector();
  nstr.NorthdrawStreet();
  sstr.SouthdrawStreet();
  pLot.drawLot();
  enterGate.drawGate();
  exitGate.drawGate();
}

public boolean dateEquals(Date a, Date b ) 
{//Compares two dates and returns true if they are the same time.
  if (a.today==b.today && a.hour==b.hour && a.minute==b.minute && a.before_noon==b.before_noon) 
  {
    return true;
  } else return false;
}

public void mousePressed()
{
 if(!pause){
 noLoop();
 pause=true;
 }else{
 loop();
 pause=false;
 }
}


class Car 
{
  int positionX, positionY, speed;//x y position of the car
  int parkTime; //Random number, decides how long the car will stay in the lot, if it were to enter.
  Date leaveDate;//Date that the car will leave (Leave date is the current date + the number of hours generated from parkTime)
  boolean willPark, inLot, leftLot;//Indicators of what "Stage" the car is in. Mainly used to decide which drive function to use.
  String stallNumber;//Tracks the stall the car was in, (to reset it when it leaves)
  int c;//The colour of the car



  Car(int x, int y) 
  { //Car constructor
    positionX=x;
    positionY=y;
    parkTime= PApplet.parseInt(random(1, 12));//Number of hours the car will stay in the lot (Between 4 and 9 hours)
    speed=2;
    if (PApplet.parseInt(random(1, 4))<=2)//If random number between 1 and 3 is either 1 or 2, then the car will park in the lot, if number is 3 then the car will not park in lot
      willPark=true;
    else willPark=false;
    c = color(PApplet.parseInt(random(0, 256)), PApplet.parseInt(random(0, 256)), PApplet.parseInt(random(0, 256)));
  }





  public void driveCar() 
  { //Main member function. This will be called from draw coninuously, must call all other functions
    strokeWeight(3);
    fill(c);

    if (willPark&& positionX==480 && !inLot && !leftLot&&enterGate.counter!=60) 
    {//If parking car is at the top of the parking lot then it will turn in and drive in
      driveIn();
      if (willPark && positionX==480 && positionY>=101) 
      {//Once it is in the lot then the car will be hidden then it will choose its stall & set it to occupied

        inLot=true;//CAR IS IN LOT
        cP.customers++;
        hideCar();
        getLeaveDate(presentDate);
        enterGate.counter++;

        //SET STALL OCCUPIED
        int secR=PApplet.parseInt(random(0, 3));
        int secC=PApplet.parseInt(random(0, 2));
        int stallR=PApplet.parseInt(random(0, 2));
        int stallC= PApplet.parseInt(random(0, 5));

        while (pLot.section[secR][secC].stall[stallR][stallC].occupied==true) 
        {
          //If the stall is already occupied, a new stall will be chosen
          //A new stall will be chosen every time until one that is free is identified.
          secR=PApplet.parseInt(random(0, 3));
          secC=PApplet.parseInt(random(0, 2));
          stallR=PApplet.parseInt(random(0, 2));
          stallC= PApplet.parseInt(random(0, 5));
        }
        if (pLot.section[secR][secC].stall[stallR][stallC].occupied==false)
        {
          //Once an empty stall is chosen, it will be set to occupied
          pLot.section[secR][secC].stall[stallR][stallC].setStatus(true, presentDate);
          stallNumber= Integer.toString(secR) + Integer.toString(secC) + Integer.toString(stallR) + Integer.toString(stallC);
        }
      }
    } else if (inLot&& dateEquals(leaveDate, presentDate)) 
      { 
        //Checks when it is time for the car to leave, if so following if statement will be activated & the car will leave the lot
        inLot=false;
        leftLot=true;
        enterGate.counter--;

        //SET STALL TO OPEN
        pLot.section[stallNumber.charAt(0)-'0'][stallNumber.charAt(1)-'0'].stall[stallNumber.charAt(2)-'0'][stallNumber.charAt(3)-'0'].occupied=false;
        positionX=480;//Puts the car at the exit of the lot
        positionY=600;
        Price_Calculator calculateFee= new Price_Calculator(presentDate);//Calculates price when car leaves. Rate is determined based on leaving day.
        exitGate.fee= calculateFee.total_price(parkTime);
        cP.revenue+=exitGate.fee;
      } 
      else if (leftLot && positionY<680) 
      {
        driveOut();//drives the car down the lot towards south street
      } else  if (!inLot)
        driveThrough();//Drives car to the left, on the street that it is currently on. (South street if they have just left the lot, or north street if they have not.)
  }



  public void driveIn() 
  { //Funtion to drive the car into the lot
    positionY+=speed;
    fill(c);
    rect(positionX, positionY, 20, 50);


  }




  public void driveOut() 
  { //Function to drive a car out of the lot, down directly out of the lot
    positionY+=speed;
    fill(c);
    rect(positionX, positionY, 20, 50);
  }



  public void driveThrough() 
  { //function to drive a car driving left through the street, not entering the lot, or after it has exited the lot. (willPark has value where the car will not go in lot)
    if(!leftLot){
    positionY=50;
    if(willPark){
      fill(255);
        text("Parking",positionX+5,positionY-10);
}
    }
    if(leftLot){
    positionY=700;
    }
    positionX+=speed;
    fill(c);
    rect(positionX, positionY, 50, 20);
  }



  public void hideCar() {//Set position off screen
    positionX=-100;
    positionY=-100;
  }


  public void getLeaveDate(Date a) {//Activated when car enters lot
    leaveDate=new Date(a.today, a.hour, a.minute, a.before_noon);
    //Sets the leaving date for the time in future when the car is to leave the lot
    for (int i=0; i<parkTime; i++) {
      leaveDate.addHour();
    }
  }
}
class ControlPanel{
  int time;
  int customers;
  float revenue;
  
  
  public void DrawControlPanel()
  {    
    fill(255);
    rect(1000,115,200,560);
    rect(1000,115,200,100);
    rect(1000,215,200,150);

    fill(0);
    text("Parking Rates:",1050,255);
    text("$3.00/hr  Monday-Saturday", 1010,280);
    text("$1.50/hr  Sunday", 1010,300);
    text("Current time:", 1050,155);
    text(presentDate.toString(),1010,180);
    text("Net Profit:",1050,400);
    text("$ "+revenue+"0",1010,425);
    text("Customers:", 1050, 475);
    text(customers,1010,500);
    text("Hours Elapsed:  "+time/60,1050,550);
   
  }
  
  
  
  
}
class Date { 
  final String[] days = {"Monday ", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
  int today;
  int hour;
  int minute;
  boolean before_noon;

  Date(int d, int h, int m, boolean beforeNoon) {


if (h<13)//If the hour is in 12-hour format, the beforeNoon argument is used
      before_noon=beforeNoon;
    else {
      if ((h%24)>=12) {//If not, the time of day is determined by the 24-hour clock equivalent of the inputted hour (e.g. hour 14 is interpreted as 2PM)
        before_noon= false;
      } else 
      before_noon = true;
    }
    
    if (m>=60) {//Adjusts minute/hour
      h+=(m/60);
      
    }
    if (h>24) {//Adjusts hour/day
      d+=(h/24);
  }
    

    today=d%7;
    hour = h%12;
    if(hour==0 && before_noon==false){//If hour is 12PM (noon), 12 PM is displayed
    hour =12;

    }//if hour is 12 AM then 00 AM is displayed
    minute = m%60;
  }
  Date(Date d) {

    today = d.today;
    hour = d.hour;
    minute = d.minute;
    before_noon = d.before_noon;
  }


  public void addHour() {
    hour +=1;
    if (hour==12) {
      if (before_noon==true)  //If AM, change to PM
        before_noon=false;
      else {//If PM, change to AM
        before_noon=true;
        today+=1;
        if (today==7)//If day is increased from sunday to monday, the today value is ajusted
          today=0;
      }
    }
    if (hour == 13)
    hour=1;
    
    }
    
    public void addMinute(){
    minute+=1;
    if(minute==60){
    addHour();
    minute =0;
    }
    
    }


    public String toString() {

      String date = days[today];
      //Format hour
      if (hour<10)
        date +=" 0"+ hour;
      else 
      date +=" "+hour;
      //Format minute;
      if (minute<10)
        date+=":0"+minute;
      else date+=":"+minute;
      //Format Time of Day
      if (before_noon)
        date+="AM";
      else 
      date+="PM";

      return date;
    }
}
class Gate{
boolean status;
int xPos, yPos, counter;//counter counts how many cars are inside the parking lot
String name;
float fee;// The fee that each car owes--Determined by price calclulator

Gate(int x, int y, String s)
{ //Gate constructor which sets the position of the gate
xPos=x;
yPos=y;
name=s;

}


public void drawGate()
{
  //Draws Gate
fill(255);
stroke(0);
strokeWeight(1);
rect(xPos,yPos,90,25);
fill(0xff87CEFA);
rect(xPos,yPos+25,90,25);
fill(0);
textSize(16);
text(name,xPos+4, yPos+20);
//Sets data fields for the possible types of gate
if(name.equals("Entrance"))
{
  if(counter>=60)
  {
    fill(255,0,0);
    text("LOT FULL", xPos+4, yPos+40);

  }else
  {
    fill(0);
    text("Spaces: "+ (60-counter), xPos+4, yPos+40);
  }
}
else 
{
  textSize(13);
  fill(0);
text("Fee: $"+ fee+"0", xPos+4, yPos+40);//the fee will be displayed once a car leaves & the exitGate.fee variable is changed.

}

if(counter>=60)
{// Closes the gate once the lot is full.
closeGate();
}else openGate();

}

public void openGate()
{
strokeWeight(7);
line(xPos+90,yPos+20,xPos+90,yPos+80);
status = true;

}

public void closeGate()
{
  strokeWeight(7);
  line(xPos+90,yPos+20,xPos+150,yPos+20);
  status = false;
}

}
class ParkingLot {

  ParkingStallSection section[][];

  //LOT coordinates. (Spacing between each section)
  int lotx;
  int loty;


  ParkingLot(int a, int b, int c, int d) 
  {

    lotx=a;
    loty=b;

    section= new ParkingStallSection [3][2];


//Setting the coordinates of each section
    for (int i =0; i<3; i++) 
    {
      for (int j=0; j<2; j++) 
      {
        section[i][j]= new ParkingStallSection(lotx, loty, c, d);//50 are width and height of the stall
        lotx+=395;
      }
      loty+=150;
      lotx=a;
    }
  }
  public void drawLot() 
  {
    for (int i=0; i<3; i++) 
    {
      for (int j=0; j<2; j++) 
      {
        section[i][j].drawSection();//draws each section
      }
    }
  }
}

class ParkingStall {
  // STALL ATTRIBUTES
  boolean occupied;
  Date timeTaken;

  // DIMENSIONS AND POSITION
  float stallWidth;
  float stallHeight;//
  float posX;
  float posY;

  ParkingStall(float x, float y, float w, float h)
  {
    occupied = false;
    posX = x;
    posY = y;
    stallWidth = w;
    stallHeight = h;
  }

  public void drawStall() 
  {
    if (occupied)
      fill(color(255, 90, 71)); // RED STALL
    else
      fill(color(152, 251, 152));  // GREEN STALL
    strokeWeight(4);
    stroke(255);
    rect(posX, posY, stallWidth, stallHeight);
    strokeWeight(1);
  }

  // Sets whether the stall is occupied or not
  public void setStatus(boolean status, Date time)
  {
    occupied = status;
    if (occupied) {
      timeTaken = new Date(time);
    }
  }
}
class ParkingStallSection {

  ParkingStall [][]stall;
  int x, y, w, h;


  ParkingStallSection(int a, int b, int c, int d) 
  {
    x=a;
    y=b;
    w=c;
    h=d;
    stall=new ParkingStall[2][5];

    for (int i=0; i<2; i++) 
    {
      for (int j=0; j<5; j++) 
      {
        stall[i][j]= new ParkingStall(x,y,w,h);
        x+=w;
      }
      y+=h;
      x=a;
    }
  }
  public void drawSection()
  {
  
  for (int i=0; i<2; i++) 
  {
      for (int j=0; j<5; j++) 
      {
        stall[i][j].drawStall();        
      }
    }
  }
}
class Price_Calculator {
  float rate;
  float price;
  Price_Calculator(Date a) 
  {
    if (a.today!=6) 
    {
      rate=3; //      $/hr
    } else {
      rate=1.5f;
    }
  }
  public float total_price(int num_of_hours) 
  { 
     //Each car will have a member variable determining how long it will stay in the lot.
     //This value is the itn inputted into this function.
    price = num_of_hours*rate;
    return price;
  }
}
class Street {

  int b;
  int c;

Street(int x, int y) {
  b = x;
  c = y;


}

public void NorthdrawStreet()
{
    noStroke();
    fill(78,78,78);
    rect(c, b, width, height/7);
    fill(255,255,255);
    textSize(20);
    text("North Street",530,30);
     
}
public void SouthdrawStreet()
{
    noStroke();
    fill(78,78,78);
    rect(b, c , width, height/7);
    fill(255,255,255);
    text("South Street",530,760);
     
}
public void DrawConnector()
{
    noStroke();
    fill(78,78,78);
    rect(460,c, 70, height);
   
   
     
}
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "ParkingLotSimulator" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
